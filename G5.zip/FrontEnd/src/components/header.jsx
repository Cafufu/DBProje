import React from 'react'
import '../css/header.css'
function header() {
    return (
        <div className="ad-banner">
            <h1>Enerji Tasarrufu Takip ve Tavsiye Sistemi (GreenSaver)</h1>
        </div>
    )
}

export default header